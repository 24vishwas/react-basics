import React from 'react'

const Home = () => {
  return (
   <div className='container'>
        <h1>Welcome to home page!</h1>
   </div>
  )
}

export default Home