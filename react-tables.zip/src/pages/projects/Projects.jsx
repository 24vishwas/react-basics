import React from 'react'

const Projects = () => {
  return (
    <div className='container'>
        <h1>Project page</h1>
    </div>
  )
}

export default Projects